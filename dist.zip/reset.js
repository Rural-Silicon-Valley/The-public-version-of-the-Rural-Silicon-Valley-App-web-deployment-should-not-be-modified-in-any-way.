// 重置应用状态
localStorage.clear();
alert('应用状态已重置，请刷新页面');
